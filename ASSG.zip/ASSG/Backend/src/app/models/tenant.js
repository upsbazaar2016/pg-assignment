export class Tenant {
    building;
    name;
    address;
    pan;
    aadhar;

    constructor(user) {
        this.building = user.building;
        this.name = user.name;
        this.address = user.address;
        this.pan = user.pan;
        this.aadhar = user.aadhar;
    }

    createTenant(user) {
        this.building = user.building;
        this.name = user.name;
        this.address = user.address;
        this.pan = user.pan;
        this.aadhar = user.aadhar;
    }

    getTenantDetails = () => {
        return {
            building: this.building,
            name: this.name,
            address: this.address,
            pan: this.pan,
            aadhar: this.aadhar,
        }
    }
}