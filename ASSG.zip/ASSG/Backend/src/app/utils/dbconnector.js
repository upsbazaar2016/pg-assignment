const mongoClient = require('mongodb').MongoClient;

module.exports = {
    getConnection: async (callback) => {
        try {
            await mongoClient.connect(process.env.MONGO_URL, { useUnifiedTopology: true }, (err, db) => {
                if (err) {
                    throw new Error(err.message);
                }
                callback(db);
            });
        }
        catch (exp) {
            throw new Error(exp)
        }
        
    }

}