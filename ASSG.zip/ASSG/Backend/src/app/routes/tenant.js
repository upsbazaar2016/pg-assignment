const router = require('express').Router();
const { createTenant, getTenantList, getTenant, updateTenant, deleteTenant } = require('./../services/tenant-service');

router.get('/', async (req, res) => {
    res.status(200).send({ 'result': await getTenantList(req.query) })    
});

router.get('/:tenantId', async (req, res) => {
    res.status(200).send({ 'result': await getTenant(req.params.tenantId) })    
});

router.post('/', async (req, res) => {
    res.status(200).send({ 'result': await createTenant(req.bpdy) })    
});

router.patch('/:tenantId', async (req, res) => {
    res.status(200).send({ 'result': await updateTenant(req.params.tenantId, req.body) })    
});

router.delete('/:tenantId', async (req, res) => {
    res.status(200).send({ 'result': await deleteTenant(req.params.tenantId) })    
});


module.exports = router;