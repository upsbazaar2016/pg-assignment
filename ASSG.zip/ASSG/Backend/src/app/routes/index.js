const router = require('express').Router();
const tenantRoutes = require('./tenant');

router.use('/tenants', tenantRoutes);


module.exports = router;