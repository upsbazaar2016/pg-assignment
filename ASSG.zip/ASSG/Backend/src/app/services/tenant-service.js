const { getConnection } = require('./../utils/dbconnector');

module.exports = {
    createTenant: async (body) => {
        try {
            getConnection((db) => {
                return new Promise(() => {
                    db.collection('tenants').insertOne({ 
                        building: body.building,
                        name: body.name,
                        address: body.address,
                        pan: body.pan,
                        aadhar: body.aadhar  
                    }).toArray();
                }, () => {
                });
            });
        }
        catch (exp) {
            throw new Error(exp);
        }
    },
    getTenantList: async (query) => {
        try {
            const { building } = query;
            getConnection((db) => {
                return new Promise(() => {
                    db.getCollection('tenants').findOne({ building }).toArray();
                }, () => {
                });
            });
        }
        catch (exp) {
            throw new Error(exp);
        }
    },
    getTenant: async (id) => {
        try {
            getConnection((db) => {
                return new Promise(() => {
                    db.collection('tenants').findOne({ _id: id });
                }, () => {
                });
            });
        }
        catch (exp) {
            throw new Error(exp);
        }
    },
    updateTenant: async (id, body) => {
        try {
            getConnection((db) => {
                return new Promise(() => {
                    db.collection('tenants').updateOne({ _id: id }, { $set: { building: body.building, name: body.name, address: body.address, pan: body.pan, aadhar: body.aadhar }});
                }, () => {
                });
            });
        }
        catch (exp) {
            throw new Error(exp);
        }
    },
    deleteTenant: async (id) => {
        try {
            getConnection((db) => {
                return new Promise(() => {
                    db.collection('tenants').deleteOne({ _id: id });
                }, () => {
                });
            });
        }
        catch (exp) {
            throw new Error(exp);
        }
    }
}