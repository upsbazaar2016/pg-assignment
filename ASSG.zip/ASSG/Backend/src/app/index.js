const 
express = require('express'),
app = express(),
cors = require('cors'),
dotenv = require('dotenv'),
routes = require('./routes/');

dotenv.config();

const PORT = process.env.PORT;

app.use(cors());

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api', routes);

app.listen(PORT, () => {
    console.log(`Server listening on PORT = ${PORT}`);
});