import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-tenant',
  templateUrl: './add-tenant.component.html',
  styleUrls: ['./add-tenant.component.css']
})
export class AddTenantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
