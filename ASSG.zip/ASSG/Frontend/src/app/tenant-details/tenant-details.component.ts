import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant-details',
  templateUrl: './tenant-details.component.html',
  styleUrls: ['./tenant-details.component.css']
})
export class TenantDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
