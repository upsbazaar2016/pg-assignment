import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private http: HttpClient) { }

  createTenant = (tenant: any) => this.http.post(`${environment.api}/tenants/`, tenant);

  getTenantList = (buidlingId: string) => this.http.get(`${environment.api}/tenants?building=${buidlingId}`); 

  getTenantDetais = (tenantId: string) => this.http.get(`${environment.api}/tenants/${tenantId}`);

  updateTenant = (tenantId: string, tenant: any) => this.http.patch(`${environment.api}/tenants/${tenantId}`, tenant); 

  deleleTenant = (tenantId: string) => this.http.delete(`${environment.api}/tenants/${tenantId}`); 
}
