import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TenantListComponent } from './tenant-list/tenant-list.component';
import { TenantDetailsComponent } from './tenant-details/tenant-details.component';
import { AddTenantComponent } from './add-tenant/add-tenant.component';

const routes: Routes = [
  {
    path: '',
    component: TenantListComponent
  },
  {
    path: 'add',
    component: AddTenantComponent
  },
  {
    path: ':id',
    component: TenantDetailsComponent
  },
  {
    path: '**',
    redirectTo: '',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
